# Raia Reasoning Agent VS Code Extension  
Installation & Usage Guide

This guide explains how to install and run the Raia Reasoning Agent VS Code extension using the hardcoded configuration version.

---

## ✅ 1. Download & Extract

1. Download the ZIP file (provided by ChatGPT).
2. Extract it anywhere on your machine.
3. You should see a folder containing:
   - `package.json`
   - `tsconfig.json`
   - `.vscode/launch.json`
   - `src/extension.ts`
   - `.gitignore`
   - `README.md`
   - `INSTALL.md` (this file)

---

## ✅ 2. Open the Project in VS Code

1. Open **VS Code**
2. Go to **File → Open Folder…**
3. Select the extracted extension folder.

---

## ✅ 3. Install Dependencies

Open a terminal inside VS Code:

```bash
npm install
```

This installs `typescript`, `vscode` types, and other necessary dependencies.

---

## ✅ 4. Insert Your Raia Agent API Key

Open:

```
src/extension.ts
```

At the top, find this section:

```ts
const RAIA_API_URL = "https://api.raia2.com";
const RAIA_AGENT_KEY = "{put your Agent API key}";
const RAIA_PROMPT_PREFIX =
  "You are a Raia reasoning AI Agent helping modernize and improve this codebase.";
const POLL_INTERVAL_MS = 1000;
const MAX_WAIT_MS = 120000;
```

Replace:

```ts
"{put your Agent API key}"
```

with your real **Raia Agent-Secret-Key**.

Example:

```ts
const RAIA_AGENT_KEY = "sk-raia-xxxxxx";
```

---

## ✅ 5. Build the Extension

Compile the TypeScript:

```bash
npm run compile
```

This generates the `out/` directory and compiled JavaScript.

---

## ✅ 6. Run the Extension (Development Mode)

Press **F5** in VS Code.

This launches a new window:

### ➜ *Extension Development Host*

Your Raia Reasoning extension is now active in that window.

---

## ✅ 7. Use the Command

Inside the **Extension Development Host**:

1. Open any code file.
2. Select some code (or leave nothing selected to send the whole file).
3. Press:

```
Cmd/Ctrl + Shift + P
```

4. Run:

```
Raia: Ask Reasoning Agent
```

5. Enter your instruction, e.g.:

- “Refactor this function.”
- “Rewrite this using async/await.”
- “Explain potential risks in this code.”

The extension will:

- Send the code + instruction to `/external/prompts/async`
- Poll `/external/prompts/{id}/response-on`
- Display the reasoning result in a new tab.

---

## 🧩 Notes

- This version uses **hardcoded config** for reliability during setup.
- You can later convert it back to a settings-configurable extension.

---

## 🆘 Troubleshooting

**Problem:** “Raia error: Failed async prompt…”  
→ Ensure your Agent key is correct and the Agent has API Skill enabled.

**Problem:** ~2 minutes pass and no response  
→ Increase `MAX_WAIT_MS`.

**Problem:** Output is raw JSON  
→ Your agent may return structured data; update `waitForPromptResult()` to parse accordingly.

---

You're all set! 🚀  
If you'd like, I can also generate a `.vsix` packaged installer or a version that supports diff-application.  
