# Raia Reasoning Agent VS Code Extension

This extension lets you send selected code from VS Code to a Raia Reasoning Agent using `/external/prompts/async`.

## Installation Instructions

1. Download the ZIP file.
2. Extract it to a folder.
3. Open VS Code → File → Open Folder → select the extracted folder.
4. Run `npm install`
5. Press **F5** to launch the Extension Development Host.
6. In the new window, open Settings → search "Raia":
   - Set **Raia API URL** (default: https://api.raia2.com)
   - Set **Agent Secret Key**
7. Open any code file → select text → run **Raia: Ask Reasoning Agent**.

