import * as vscode from "vscode";

// *** HARDCODED CONFIGURATION FOR CHALLENGE WIN ***
// This overrides the settings configuration to guarantee success.
const RAIA_API_URL = "https://api.raia2.com";
const RAIA_AGENT_KEY = "{INSERT RAIA API KEY FOR AGENT";
const RAIA_PROMPT_PREFIX = "You are a Raia reasoning AI Agent helping modernize and improve this codebase.";
const POLL_INTERVAL_MS = 1000;
const MAX_WAIT_MS = 120000;


function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 1. Sends the prompt and gets an ID for the result.
async function createPromptAsync(apiUrl: string, agentSecretKey: string, prompt: string): Promise<string> {
  const res = await fetch(apiUrl + "/external/prompts/async", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Agent-Secret-Key": agentSecretKey
    },
    body: JSON.stringify({ prompt })
  });

  if (!res.ok) throw new Error("Failed async prompt: " + (await res.text()));

  const json = await res.json();
  // Ensure we get the ID from the response, which is crucial for polling.
  return json.promptId; 
}

// 2. Polls the API until the result is ready or times out.
async function waitForPromptResult(apiUrl: string, agentSecretKey: string, promptId: string, poll: number, timeout: number) {
  const end = Date.now() + timeout;

  while (Date.now() < end) {
    const res = await fetch(`${apiUrl}/external/prompts/${promptId}/response-on`, {
      method: "GET",
      headers: { "Agent-Secret-Key": agentSecretKey }
    });

    if (!res.ok) throw new Error("Polling error: " + (await res.text()));

    const txt = await res.text();

    // The API returns the text response once it's ready
    if (txt && txt.trim() !== "" && txt.trim() !== "null") {
      // The response is usually the raw response content, sometimes JSON
      try {
        return JSON.parse(txt);
      } catch {
        return { response: txt }; // Handle cases where it returns plain text
      }
    }

    await sleep(poll);
  }

  return null;
}

export function activate(context: vscode.ExtensionContext) {
  // --- COMMAND REGISTRATION ---
  const disposable = vscode.commands.registerCommand("raia.askReasoningAgent", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) return vscode.window.showErrorMessage("No editor open. ");

    const selection = editor.selection;
    // Get the selected code or the whole file content
    const code = editor.document.getText(selection) || editor.document.getText();

    if (!code) return vscode.window.showErrorMessage("No code selected.");

    const instruction = await vscode.window.showInputBox({
      prompt: "What should the Raia reasoning agent do?"
    });
    if (!instruction) return;

    // Use hardcoded values instead of reading from configuration settings
    const apiUrl = RAIA_API_URL;
    const key = RAIA_AGENT_KEY;
    const prefix = RAIA_PROMPT_PREFIX;
    const poll = POLL_INTERVAL_MS;
    const timeout = MAX_WAIT_MS;

    const prompt = `${prefix}

Instruction:
${instruction}

Code:
${code}`;

    await vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: "Raia reasoning agent thinking...",
      cancellable: false
    }, async () => {
      try {
        const id = await createPromptAsync(apiUrl, key, prompt);
        const result = await waitForPromptResult(apiUrl, key, id, poll, timeout);

        if (!result) return vscode.window.showWarningMessage("Timed out waiting for Raia response.");

        // Open the result in a new document beside the current editor
        const doc = await vscode.workspace.openTextDocument({
          content: result.response,
          language: editor.document.languageId
        });

        vscode.window.showTextDocument(doc, vscode.ViewColumn.Beside);
      } catch (err: any) {
        // This will catch the API and Polling errors
        vscode.window.showErrorMessage("Raia error: " + err.message);
      }
    });
  });

  context.subscriptions.push(disposable);
}

export function deactivate() {}